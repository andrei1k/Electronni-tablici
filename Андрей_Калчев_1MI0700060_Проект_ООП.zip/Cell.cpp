#include "Cell.h"
#include "IntCell.h"
#include "DoubleCell.h"
#include "StringCell.h"
#include "ValuteCell.h"



Cell::Cell(unsigned row, unsigned column, unsigned width, CellType type, std::string value) : position(row, column), width(width), type(type), value(value) {}

CellType Cell::getType() const
{
	return this->type;
}

std::string Cell::val() const {

	return this->value;
}

unsigned Cell::getWidth() const
{
	return this->width;
}

Pair Cell::getPosition() const
{
	return this->position;
}

void Cell::changeRow(unsigned row)
{
	this->position.fst = row;
}

int slashesCount(const std::string& value, int i) {

	int count = 0;

	for (; i >= 0 && value[i] == '\\'; i--) {
		count++;
	}
	return count;
}

std::string removeWhiteSpaces(const std::string& value)
{
	std::string newVal;
	bool start = true;
	for (unsigned i = 0; i < value.size(); i++) {
		if ((value[i] == ' ' || value[i] == 9) && start)
			continue;
		else {
			start = false;
			newVal.push_back(value[i]);
		}
	}

	return newVal;
}

CellType typeOfString(const std::string& value)
{
	if (value == "" || value[0] == '\0')
		return CellType::EMPTY;

	if (value[0] == '"' && value.back() == '"' && value.size() > 1) {

		bool first = true;
		bool isString = true;
		for (unsigned i = 1; i < value.size() - 1; i++) {
			if (value[i] == '\\') {
				if (first) {
					if (value[i + 1] != '\\' && value[i + 1] != '\'' && value[i + 1] != '\"') {
						isString = false;
						break;
					}
					first = false;
					continue;
				}
				
			}
			first = true;
			if ((value[i] == '\'' || value[i] == '\"') && slashesCount(value, i-1) % 2 == 0) {
				isString = false;
				break;
			}
		}

		if (isString) {
			return CellType::STRING;
		}	
	}

	if (value.find("$") != std::string::npos || value.find("�") != std::string::npos) {

		bool isValute = true;
		if (value.size() < 3)
			return CellType::INVALID;
		if (value[1] != ' ' && (value[1] < '0' || value[1] > '9'))
			isValute = false;

		for (unsigned i = 2; i < value.size() - 3; i++) {

			if ((value[i] < '0' || value[i] > '9')) {

				isValute = false;
				break;
			}
		}
		
		if (value[value.size() - 3] != '.')
			isValute = false;
		if ((value[value.size() - 2] < '0' || value[value.size() - 2] > '9') || (value[value.size() - 1] < '0' || value[value.size() - 1] > '9'))
			isValute = false;

		if (isValute)
			return CellType::VALUTE;

	}

	if (value.find("lv.") != std::string::npos ) {

		bool isValute = true;
		try {
			double valuteValue = stod(value);
			for (unsigned i = 0; i < value.find("lv.") - 4; i++) {

				if ((value[i] < '0' || value[i] > '9')) {

					isValute = false;
					break;
				}
			}
			if (value.size() != value.find("lv.") + 3)
				isValute = false;
			if (value[value.find("lv.") - 1] != ' ')
				isValute = false;
			if (value[value.find("lv.") - 4] != '.')
				isValute = false;
			if ((value[value.find("lv.") - 3] < '0' || value[value.find("lv.") - 3] > '9') || (value[value.find("lv.") - 2] < '0' || value[value.find("lv.") - 2] > '9'))
				isValute = false;
		}
		catch (...) {

			isValute = false;
			return CellType::INVALID;
		}
		

		if (isValute)
			return CellType::VALUTE;
	}

	for (unsigned i = 0; i < value.size(); i++) {
		if (value[0] == '+' || value[0] == '-')
			if (i == 0)
				continue;

		if (i + 1 == value.size() && !(value[i] < '0' || value[i] > '9'))
			return CellType::INT;

		if (value[i] < '0' || value[i] > '9')
			break;
	}

	bool oneDecimalDot = false;
	for (unsigned i = 0; i < value.size(); i++) {
		if (value[0] == '+' || value[0] == '-')
			if (i == 0)
				continue;

		if (i + 1 == value.size() && !(value[i] < '0' || value[i] > '9'))
			return CellType::DOUBLE;

		if ((value[i] < '0' || value[i] > '9')) {
			if (value[i] == '.') {
				if (!oneDecimalDot)
					oneDecimalDot = true;
				else break;
			}
			else break;
		}
	}

	return CellType::INVALID;
}


Cell* createCell(unsigned row, unsigned column, std::string value)
{
	value = removeWhiteSpaces(value);

	CellType typeCheck = typeOfString(value);
	//std::cout << value << typeCheck;
	switch (typeCheck)
	{
	case CellType::INVALID: throw std::invalid_argument(value);
	case CellType::INT: return new IntCell(row, column, value);
	case CellType::DOUBLE: return new DoubleCell(row, column, value);
	case CellType::STRING: return new StringCell(row, column, value);
	case CellType::VALUTE: return new ValuteCell(row, column, value);
	case CellType::EMPTY: return new EmptyCell(row, column);
	default: return nullptr;
	}

}